"""
硬编码情感分类插件
直接在代码中定义情感分类信息
"""

from typing import Dict, Any
from src.data.label_parser_plugin_interface import LabelParserPlugin


class HardcodedEmotionCategoriesPlugin(LabelParserPlugin):
    """硬编码情感分类插件"""
    
    def get_name(self) -> str:
        """获取插件名称"""
        return "hardcoded_emotion_categories"
    
    def get_description(self) -> str:
        """获取插件描述"""
        return "硬编码情感分类信息"
    
    def get_categories(self) -> Dict[str, Any]:
        """
        获取硬编码的情感分类信息
        
        Returns:
            情感分类信息字典
        """
        # 硬编码的情感分类体系
        categories = {
            "01": {
                "id": "01",
                "name_zh": "喜悦",
                "name_en": "Joy",
                "secondaries": [
                    {
                        "id": "01.01",
                        "name_zh": "愉悦",
                        "name_en": "Pleasure"
                    },
                    {
                        "id": "01.02",
                        "name_zh": "赞赏",
                        "name_en": "Admiration"
                    }
                ]
            },
            "02": {
                "id": "02",
                "name_zh": "悲伤",
                "name_en": "Sadness",
                "secondaries": [
                    {
                        "id": "02.01",
                        "name_zh": "忧郁",
                        "name_en": "Melancholy"
                    },
                    {
                        "id": "02.02",
                        "name_zh": "哀伤",
                        "name_en": "Grief"
                    }
                ]
            }
        }
        
        return categories