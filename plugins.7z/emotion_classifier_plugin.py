"""
情感分类器插件
完全由插件提供情感分类信息
"""

import logging
from typing import Dict, Any, List, Optional
import sys
import os

# 获取项目根目录并添加到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# 添加 data-visualizer 目录到 Python 路径
data_visualizer_path = os.path.join(project_root, 'poetry-annotator-data-visualizer')
if data_visualizer_path not in sys.path:
    sys.path.insert(0, data_visualizer_path)

from data_visualizer.db_manager import DBManager
from src.data.label_parser_plugin_interface import LabelParserPlugin
from src.config.schema import PluginConfig

# 初始化日志记录器
logger = logging.getLogger(__name__)

# --- 核心数据结构定义 ---

# 用于存储情感分类的内部表示
# key: emotion_id (e.g., "01.05")
# value: {"name_zh": "愉悦", "name_en": "Joy", "parent_id": "01", "level": 2}
EmotionCategoryMap = Dict[str, Dict[str, Any]]


class EmotionClassifierPlugin(LabelParserPlugin):
    """情感分类器插件，负责管理情感分类体系。"""

    def __init__(self, config: Optional[PluginConfig] = None):
        """
        初始化情感分类器插件。

        :param config: 插件配置
        """
        super().__init__(config)
        self.db_manager = None
        self._emotion_categories: Optional[EmotionCategoryMap] = None
        self._initialize_db_manager()
        self._load_emotion_categories()

    def _initialize_db_manager(self):
        """初始化数据库管理器。"""
        try:
            # 从配置中获取数据库路径
            db_path = self.config.settings.get('db_path', 'data/emotions.db')
            self.db_manager = DBManager(db_path)
            logger.info("数据库管理器初始化成功")
        except Exception as e:
            logger.error(f"数据库管理器初始化失败: {e}")
            self.db_manager = None

    def _load_emotion_categories(self):
        """
        从数据库加载情感分类体系到内存，构建便于查询的映射结构。
        """
        if not self.db_manager:
            logger.warning("数据库管理器未初始化，无法加载情感分类")
            self._emotion_categories = {}
            return

        try:
            df = self.db_manager.get_all_emotion_categories()
            self._emotion_categories = {}
            for _, row in df.iterrows():
                self._emotion_categories[row['id']] = {
                    'name_zh': row['name_zh'],
                    'name_en': row['name_en'],
                    'parent_id': row['parent_id'],
                    'level': row['level']
                }
            logger.info(f"成功加载 {len(self._emotion_categories)} 个情感分类。")
        except Exception as e:
            logger.error(f"加载情感分类体系失败: {e}")
            self._emotion_categories = {}

    def get_name(self) -> str:
        """获取插件名称。"""
        return "emotion_classifier"

    def get_description(self) -> str:
        """获取插件描述。"""
        return "基于数据库的情感分类器插件"

    def get_categories(self) -> Dict[str, Any]:
        """
        获取插件提供的分类信息。
        
        Returns:
            情感分类信息字典
        """
        # 将情感分类信息转换为插件系统期望的格式
        categories = {}
        
        if not self._emotion_categories:
            return categories
            
        # 按照一级分类组织二级分类
        primary_categories = {}
        secondary_categories = {}
        
        # 分离一级和二级分类
        for e_id, e_info in self._emotion_categories.items():
            if e_info['level'] == 1:
                primary_categories[e_id] = e_info
            elif e_info['level'] == 2:
                secondary_categories[e_id] = e_info
        
        # 组织成插件系统期望的格式
        for primary_id, primary_info in primary_categories.items():
            categories[primary_id] = {
                'id': primary_id,
                'name_zh': primary_info['name_zh'],
                'name_en': primary_info['name_en'],
                'categories': []
            }
            
            # 添加对应的二级分类
            for secondary_id, secondary_info in secondary_categories.items():
                if secondary_info['parent_id'] == primary_id:
                    categories[primary_id]['categories'].append({
                        'id': secondary_id,
                        'name_zh': secondary_info['name_zh'],
                        'name_en': secondary_info['name_en']
                    })
        
        return categories

    def get_emotion_display_info(self, emotion_id: str) -> Dict[str, str]:
        """
        根据情感ID获取用于界面显示的信息。

        :param emotion_id: 情感的唯一ID，例如 "01.05"。
        :return: 包含 'id' 和 'name' 的字典，例如 {'id': '01.05', 'name': '01.05 愉悦'}。
                 如果ID无效，则 'name' 为 '未知情感'。
        """
        if not emotion_id or not self._emotion_categories:
            return {'id': emotion_id or '', 'name': f"{emotion_id or ''} 未知情感"}

        emotion_info = self._emotion_categories.get(emotion_id)
        if not emotion_info:
            return {'id': emotion_id, 'name': f"{emotion_id} 未知情感"}

        # 格式化显示名称，例如 "01.05 愉悦"
        display_name = f"{emotion_id} {emotion_info['name_zh']}"
        return {'id': emotion_id, 'name': display_name}

    def get_full_emotion_list_for_selection(self, level: int = 2) -> List[Dict[str, str]]:
        """
        获取完整的情感分类列表，供GUI下拉选择框使用。

        :param level: 指定要获取的情感分类层级 (1: 一级分类, 2: 二级分类)。默认为2。
        :return: 一个字典列表，每个字典包含 'id' 和 'name' 键。
        """
        if not self._emotion_categories:
            return []

        emotion_list = []
        for e_id, e_info in self._emotion_categories.items():
            if e_info['level'] == level:
                display_name = f"{e_id} {e_info['name_zh']}"
                emotion_list.append({'id': e_id, 'name': display_name})

        # 按ID排序，保证列表顺序一致
        emotion_list.sort(key=lambda x: x['id'])
        return emotion_list

    def get_all_emotion_categories(self) -> EmotionCategoryMap:
        """
        获取所有情感分类信息。

        :return: 包含所有情感分类信息的字典
        """
        return self._emotion_categories.copy() if self._emotion_categories else {}

    def get_categories_text(self) -> str:
        """
        获取格式化的情感分类文本，用于提示词。

        :return: 格式化的情感分类文本
        """
        if not self._emotion_categories:
            return "## 情感分类体系：\n\n未加载情感分类信息。\n"
            
        text = "## 情感分类体系：\n\n"
        categories = self.get_categories()
        
        for category_id, category_data in categories.items():
            text += f"**{category_id} {category_data.get('name_zh', '')}** ({category_data.get('name_en', '')})\n"
            for secondary in category_data.get('categories', []):
                text += f"- **{secondary.get('id', '')} {secondary.get('name_zh', '')}** ({secondary.get('name_en', '')})\n"
            text += "\n"
        
        return text

    def get_all_categories(self) -> List[str]:
        """
        获取所有情感分类名称。

        :return: 所有情感分类名称列表
        """
        if not self._emotion_categories:
            return []
            
        categories = []
        category_data = self.get_categories()
        
        for primary_data in category_data.values():
            categories.append(primary_data.get('name_zh', ''))
            for secondary in primary_data.get('categories', []):
                categories.append(secondary.get('name_zh', ''))
                
        return categories

    def get_all_categories_with_ids(self) -> Dict[str, str]:
        """
        获取所有情感分类ID和名称的映射。

        :return: 情感分类ID和名称的映射字典
        """
        if not self._emotion_categories:
            return {}
            
        categories = {}
        category_data = self.get_categories()
        
        for primary_id, primary_data in category_data.items():
            categories[primary_id] = primary_data.get('name_zh', '')
            for secondary in primary_data.get('categories', []):
                categories[secondary.get('id', '')] = secondary.get('name_zh', '')
                
        return categories

    def validate_emotion(self, emotion: str) -> bool:
        """
        验证情感标签是否在分类体系中。

        :param emotion: 情感标签名称
        :return: 是否有效
        """
        all_categories = self.get_all_categories()
        return emotion in all_categories

    def get_primary_category(self, secondary_id: str) -> Optional[str]:
        """
        根据二级类别ID获取一级类别ID。

        :param secondary_id: 二级类别ID
        :return: 对应的一级类别ID，如果未找到则返回None
        """
        if not self._emotion_categories:
            return None
            
        for e_id, e_info in self._emotion_categories.items():
            if e_info['level'] == 1:
                # 检查该一级分类下的所有二级分类
                for sub_id, sub_info in self._emotion_categories.items():
                    if sub_info['level'] == 2 and sub_info['parent_id'] == e_id and sub_id == secondary_id:
                        return e_id
        return None