"""
自定义情感分类插件示例
"""

from typing import Dict, Any, Optional
from src.data.label_parser_plugin_interface import LabelParserPlugin
from src.config.schema import PluginConfig


class CustomEmotionPlugin(LabelParserPlugin):
    """自定义情感分类插件示例"""
    
    def __init__(self, config: Optional[PluginConfig] = None):
        super().__init__(config)
        self.name = "custom_emotion"
        self.description = "自定义情感分类插件"
    
    def get_name(self) -> str:
        return self.name
    
    def get_description(self) -> str:
        return self.description
    
    def get_categories(self) -> Dict[str, Any]:
        """
        获取插件提供的额外分类信息
        
        Returns:
            插件提供的分类信息字典
        """
        # 示例：添加自定义的情感分类
        custom_categories = {
            "99": {
                "id": "99",
                "name_zh": "复合情感",
                "name_en": "Complex Emotion",
                "secondaries": [
                    {
                        "id": "99.01",
                        "name_zh": "悲喜交加",
                        "name_en": "Bittersweet"
                    },
                    {
                        "id": "99.02",
                        "name_zh": "爱恨交织",
                        "name_en": "Love-Hate"
                    }
                ]
            }
        }
        
        return custom_categories