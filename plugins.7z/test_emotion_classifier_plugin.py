"""
情感分类器插件测试
"""

import unittest
import os
import sys
from pathlib import Path

# 将项目根目录添加到路径中
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.data.plugins.emotion_classifier_plugin import EmotionClassifierPlugin


class TestEmotionClassifierPlugin(unittest.TestCase):
    
    def setUp(self):
        """测试前准备"""
        self.plugin = EmotionClassifierPlugin()
    
    def test_plugin_initialization(self):
        """测试插件初始化"""
        self.assertIsNotNone(self.plugin)
        self.assertEqual(self.plugin.get_name(), "emotion_classifier")
        self.assertEqual(self.plugin.get_description(), "基于数据库的情感分类器插件")
    
    def test_get_categories(self):
        """测试获取分类信息"""
        categories = self.plugin.get_categories()
        # 由于没有实际数据库，这里可能返回空字典
        self.assertIsInstance(categories, dict)
    
    def test_get_emotion_display_info(self):
        """测试获取情感显示信息"""
        # 测试未知情感ID
        info = self.plugin.get_emotion_display_info("99.99")
        self.assertEqual(info['id'], "99.99")
        self.assertIn("未知情感", info['name'])
    
    def test_get_full_emotion_list_for_selection(self):
        """测试获取情感选择列表"""
        # 测试获取二级分类列表
        emotion_list = self.plugin.get_full_emotion_list_for_selection(level=2)
        self.assertIsInstance(emotion_list, list)
        
        # 测试获取一级分类列表
        emotion_list = self.plugin.get_full_emotion_list_for_selection(level=1)
        self.assertIsInstance(emotion_list, list)
    
    def test_get_all_emotion_categories(self):
        """测试获取所有情感分类"""
        categories = self.plugin.get_all_emotion_categories()
        self.assertIsInstance(categories, dict)


if __name__ == '__main__':
    unittest.main()