"""
情感分类数据导入插件
"""

from typing import Dict, Any
from src.db_initializer.plugin_interface import DatabaseInitPlugin


class EmotionImportPlugin(DatabaseInitPlugin):
    """情感分类数据导入插件"""
    
    def get_name(self) -> str:
        return "emotion_import"
    
    def get_description(self) -> str:
        return "情感分类数据导入插件，负责将情感分类体系导入到情感数据库中"
    
    def initialize_database(self, db_name: str, clear_existing: bool = False) -> Dict[str, Any]:
        """初始化情感分类数据"""
        # 在这里执行情感分类数据的导入逻辑
        if self.separate_db_manager:
            try:
                # 导入情感分类体系
                imported_count = 0
                try:
                    from ..plugin_label_parser import get_plugin_label_parser
                    label_parser = get_plugin_label_parser()
                    # 获取所有分类的详细信息，包括英文名称
                    categories_data = []
                    for primary_id, primary_data in label_parser.categories.items():
                        # 添加一级分类
                        categories_data.append({
                            'id': primary_data['id'],
                            'name_zh': primary_data['name_zh'],
                            'name_en': primary_data.get('name_en', ''),
                            'parent_id': None,
                            'level': 1
                        })
                        # 添加二级分类
                        for secondary in primary_data.get('secondaries', []):
                            categories_data.append({
                                'id': secondary['id'],
                                'name_zh': secondary['name_zh'],
                                'name_en': secondary.get('name_en', ''),
                                'parent_id': primary_data['id'],
                                'level': 2
                            })
                    
                    # 使用批量插入和事务优化性能
                    if categories_data:
                        conn = self.separate_db_manager.emotion_db.connect()
                        try:
                            # 开启事务
                            conn.execute('BEGIN TRANSACTION')
                            
                            # 准备批量插入数据
                            insert_data = [
                                (
                                    category['id'],
                                    category['name_zh'],
                                    category['name_en'],
                                    category['parent_id'],
                                    category['level']
                                )
                                for category in categories_data
                            ]
                            
                            # 执行批量插入
                            conn.executemany('''
                                INSERT OR REPLACE INTO emotion_categories 
                                (id, name_zh, name_en, parent_id, level)
                                VALUES (?, ?, ?, ?, ?)
                            ''', insert_data)
                            
                            # 提交事务
                            conn.commit()
                            imported_count = len(categories_data)
                            
                        except Exception as e:
                            # 回滚事务
                            conn.rollback()
                            raise
                        finally:
                            conn.close()
                            
                except Exception as e:
                    raise Exception(f"导入情感分类时出错: {e}")
                
                return {
                    "status": "success",
                    "message": f"情感分类数据导入完成，导入了 {imported_count} 个情感分类"
                }
            except Exception as e:
                return {
                    "status": "error",
                    "message": f"情感分类数据导入失败: {e}"
                }
        else:
            return {
                "status": "error",
                "message": "未提供分离数据库管理器"
            }