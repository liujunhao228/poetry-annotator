"""《交际诗分析》项目数据库初始化插件"""

import logging
from typing import Dict, Any
from src.db_initializer.plugin_interface import DatabaseInitPlugin

logger = logging.getLogger(__name__)

class SocialPoemAnalysisPlugin(DatabaseInitPlugin):
    """《交际诗分析》项目数据库初始化插件"""
    
    def get_name(self) -> str:
        return "social_poem_analysis"
        
    def get_description(self) -> str:
        return "《交际诗分析》项目数据库初始化插件"
        
    def initialize_database(self, db_name: str, clear_existing: bool = False) -> Dict[str, Any]:
        """初始化数据库表结构"""
        try:
            # 获取数据库适配器
            db_adapter = self.separate_db_manager.get_db_adapter(db_name)
            
            # 创建项目特定的表
            create_table_sql = """
            CREATE TABLE IF NOT EXISTS social_analysis_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poem_id INTEGER NOT NULL,
                sentence_id TEXT NOT NULL,
                relationship_action TEXT,
                emotional_strategy TEXT,
                communication_scene TEXT,
                risk_level TEXT,
                rationale TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (poem_id) REFERENCES poems (id)
            );
            """
            db_adapter.execute_script(create_table_sql)
            
            logger.info("成功初始化《交际诗分析》项目数据库表结构")
            return {
                "status": "success",
                "message": "数据库初始化成功"
            }
        except Exception as e:
            logger.error(f"初始化数据库失败: {e}")
            return {
                "status": "error",
                "message": str(e)
            }