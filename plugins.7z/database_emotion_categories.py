"""
数据库情感分类插件
从数据库获取情感分类信息
"""

import sqlite3
from typing import Dict, Any
from src.data.label_parser_plugin_interface import LabelParserPlugin
from src.config.schema import PluginConfig


class DatabaseEmotionCategoriesPlugin(LabelParserPlugin):
    """从数据库获取情感分类的插件"""
    
    def get_name(self) -> str:
        """获取插件名称"""
        return "database_emotion_categories"
    
    def get_description(self) -> str:
        """获取插件描述"""
        return "从数据库获取情感分类信息"
    
    def get_categories(self) -> Dict[str, Any]:
        """
        从数据库获取情感分类信息
        
        Returns:
            情感分类信息字典
        """
        # 获取数据库路径配置
        db_path = self.config.settings.get('db_path', 'data/emotion_categories.db')
        
        # 连接数据库并查询分类信息
        categories = {}
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # 查询一级分类
            cursor.execute("SELECT id, name_zh, name_en FROM primary_categories")
            primary_rows = cursor.fetchall()
            
            # 查询二级分类
            cursor.execute("SELECT id, primary_id, name_zh, name_en FROM secondary_categories")
            secondary_rows = cursor.fetchall()
            
            # 构建分类结构
            for row in primary_rows:
                primary_id, name_zh, name_en = row
                categories[primary_id] = {
                    'id': primary_id,
                    'name_zh': name_zh,
                    'name_en': name_en,
                    'secondaries': []
                }
            
            # 添加二级分类
            for row in secondary_rows:
                secondary_id, primary_id, name_zh, name_en = row
                if primary_id in categories:
                    categories[primary_id]['secondaries'].append({
                        'id': secondary_id,
                        'name_zh': name_zh,
                        'name_en': name_en
                    })
            
            conn.close()
        except Exception as e:
            print(f"从数据库获取情感分类时出错: {e}")
            # 返回空字典或默认分类
            return {}
        
        return categories