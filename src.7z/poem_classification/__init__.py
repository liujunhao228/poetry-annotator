"""
诗词预处理分类模块入口文件。
"""

from .poem_classification import PoemClassificationPlugin

__all__ = [
    "PoemClassificationPlugin"
]