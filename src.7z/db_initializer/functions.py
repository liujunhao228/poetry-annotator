"""
数据库初始化功能函数
从src/data/initializer.py迁移过来的函数
"""

import sys
import sqlite3
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime, timezone, timedelta

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent.parent.absolute()
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

try:
    from src.config import config_manager
except ImportError:
    # 当作为独立模块运行时
    import sys
    sys.path.append(str(Path(__file__).parent.parent))
    from src.config import config_manager


def initialize_all_databases_from_source_folders(clear_existing: bool = False) -> Dict[str, Dict[str, int]]:
    """根据source_json下的子文件夹初始化所有数据库"""
    # 延迟导入以避免循环依赖
    from src.data.manager import DataManager
    
    data_config = config_manager.get_effective_data_config()
    source_json_dir = Path(data_config['source_dir'])
    
    # 获取数据库配置
    db_config = config_manager.get_effective_database_config()
    separate_db_paths = db_config.get('separate_db_paths', {})
    
    # 获取所有子文件夹
    subfolders = [f for f in source_json_dir.iterdir() if f.is_dir()]
    
    results = {}
    
    for folder in subfolders:
        folder_name = folder.name
        
        # 如果该文件夹在数据库配置中，则使用配置的数据库路径
        if folder_name in separate_db_paths:
            db_path = separate_db_paths[folder_name]
        else:
            # 否则使用默认路径格式 data/{folder_name}.db
            db_path = f"data/{folder_name}.db"
        
        # 临时保存原始source_dir配置
        original_source_dir = config_manager.get_effective_data_config()['source_dir']
        
        # 临时修改配置管理器中的source_dir为当前子文件夹
        # 注意：这里需要修改全局配置或项目配置，具体取决于配置管理器的实现
        # 由于ConfigManager没有直接修改配置的方法，我们需要创建一个新的DataManager实例
        # 并直接传递source_dir参数
        
        try:
            # 创建DataManager实例，使用folder_name作为数据库名称
            manager = DataManager(db_name=folder_name)
            
            # 由于DataManager构造函数会自动初始化数据库，我们需要重新初始化数据
            # 但我们首先需要确保source_dir被正确设置
            # 这里我们直接修改manager的source_dir属性
            manager.source_dir = str(folder)
            
            # 初始化数据
            result = manager.initialize_database_from_json(clear_existing=clear_existing)
            results[folder_name] = result
        except Exception as e:
            print(f"处理文件夹 {folder_name} 时出错: {e}")
            results[folder_name] = {"error": str(e)}
        
    return results