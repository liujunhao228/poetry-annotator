"""
简化版数据管理器，使用插件系统
"""
import sqlite3
import json
import os
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from src.config import get_config_manager
from .adapter import get_database_adapter, normalize_poem_data
from .models import Poem, Author, Annotation
from .exceptions import DataError, DatabaseError
from datetime import datetime
from src.data.plugin_based_manager import PluginBasedDataManager


class DataManager:
    """简化版数据管理器，核心逻辑已迁移至插件系统"""
    
    def __init__(self, db_name: str = "default"):
        """初始化数据管理器"""
        # 获取配置管理器实例
        config_manager = get_config_manager()
        
        # 获取数据库配置
        db_config = config_manager.get_effective_database_config()
        
        # 处理新的分离数据库配置
        if 'separate_db_paths' in db_config:
            separate_db_paths = db_config['separate_db_paths']
            self.db_name = db_name
            
            # 从配置中获取数据库路径
            if db_name == "default":
                # 默认使用第一个数据库配置
                self.db_path = next(iter(separate_db_paths.values()))
            else:
                if db_name not in separate_db_paths:
                    raise ValueError(f"数据库 '{db_name}' 未在配置中定义。")
                self.db_path = separate_db_paths[db_name]
        else:
            raise ValueError("配置文件中未找到数据库路径配置。")
            
        # 获取数据源目录配置
        data_config = config_manager.get_effective_data_config()
        self.source_dir = data_config['source_dir']
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"数据管理器初始化 - 数据库: {self.db_path}, 数据源: {self.source_dir}")
        
        # 初始化插件化数据管理器
        project_root = Path(__file__).parent.parent.parent
        self.plugin_manager = PluginBasedDataManager(project_root, db_name)
        
        # 检查数据库文件是否存在，如果不存在则初始化
        if not Path(self.db_path).exists():
            self.logger.info(f"数据库文件 {self.db_path} 不存在，正在初始化...")
            self._initialize_database_if_not_exists()
        
        # 初始化数据库适配器
        self.db_adapter = get_database_adapter('sqlite', self.db_path)
        
        # 为不同数据库设置ID前缀，确保全局唯一性
        self._set_id_prefix()
        
        # 初始化分离数据库适配器
        self._init_separate_databases()
    
    def _init_separate_databases(self):
        """初始化分离数据库适配器，为每个主数据库创建独立的分离数据库"""
        from .separate_databases import SeparateDatabaseManager
        separate_db_manager = SeparateDatabaseManager(main_db_name=self.db_name)
        
        # 获取各个分离数据库的适配器
        self.raw_data_db = separate_db_manager.raw_data_db
        self.annotation_db = separate_db_manager.annotation_db
        self.emotion_db = separate_db_manager.emotion_db
    
    def _set_id_prefix(self):
        """为不同数据库设置ID前缀，确保全局唯一性"""
        # 定义数据库名称到前缀的映射
        db_prefixes = {
            "TangShi": 1000000,  # 唐诗ID前缀
            "SongCi": 2000000,   # 宋词ID前缀
            "YuanQu": 3000000,   # 元曲ID前缀
            "default": 0         # 默认数据库前缀
        }
        
        # 根据数据库名称设置前缀
        self.id_prefix = db_prefixes.get(self.db_name, 0)
        self.logger.info(f"数据库 {self.db_name} 的ID前缀设置为: {self.id_prefix}")
    
    @classmethod
    def initialize_all_databases_from_source_folders(cls, clear_existing: bool = False) -> Dict[str, Dict[str, int]]:
        """根据source_json下的子文件夹初始化所有数据库"""
        from ..db_initializer.functions import initialize_all_databases_from_source_folders
        return initialize_all_databases_from_source_folders(clear_existing)

    def _initialize_database_if_not_exists(self):
        """如果数据库文件不存在则初始化"""
        # 这个方法现在主要负责确保数据库文件存在
        # 实际的初始化逻辑已迁移至插件系统
        try:
            # 确保数据库目录存在
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 创建一个空的数据库文件
            with open(self.db_path, 'w') as f:
                pass
                
            self.logger.info(f"已创建空数据库文件: {self.db_path}")
        except Exception as e:
            self.logger.error(f"创建数据库文件失败: {e}")
            raise DatabaseError(f"无法创建数据库文件 {self.db_path}: {e}")
    
    # 委托给插件管理器的方法
    
    def initialize_database_from_json(self, clear_existing: bool = False) -> Dict[str, int]:
        """从JSON文件初始化数据库"""
        return self.plugin_manager.initialize_database_from_json(clear_existing)
    
    def get_poems_to_annotate(self, model_identifier: str, 
                               limit: Optional[int] = None, 
                               start_id: Optional[int] = None, 
                               end_id: Optional[int] = None,
                               force_rerun: bool = False) -> List[Poem]:
        """获取指定模型待标注的诗词"""
        return self.plugin_manager.get_poems_to_annotate(
            model_identifier, limit, start_id, end_id, force_rerun
        )
    
    def get_poem_by_id(self, poem_id: int) -> Optional[Poem]:
        """根据ID获取单首诗词信息"""
        return self.plugin_manager.get_poem_by_id(poem_id)
    
    def get_poems_by_ids(self, poem_ids: List[int]) -> List[Poem]:
        """根据ID列表获取诗词信息"""
        return self.plugin_manager.get_poems_by_ids(poem_ids)
    
    def save_annotation(self, poem_id: int, model_identifier: str, status: str,
                        annotation_result: Optional[str] = None, 
                        error_message: Optional[str] = None) -> bool:
        """保存标注结果"""
        return self.plugin_manager.save_annotation(
            poem_id, model_identifier, status, annotation_result, error_message
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        return self.plugin_manager.get_statistics()
    
    def get_annotation_statistics(self) -> Dict[str, Any]:
        """获取标注统计信息"""
        return self.plugin_manager.get_annotation_statistics()
    
    def get_all_authors(self) -> List[Author]:
        """获取所有作者信息"""
        return self.plugin_manager.get_all_authors()
    
    def search_poems(self, author: Optional[str] = None, title: Optional[str] = None, 
                     page: int = 1, per_page: int = 10) -> Dict[str, Any]:
        """根据作者和标题搜索诗词，并支持分页"""
        return self.plugin_manager.search_poems(author, title, page, per_page)
    
    def get_completed_poem_ids(self, poem_ids: List[int], model_identifier: str) -> set[int]:
        """高效检查一组 poem_id 是否已被特定模型成功标注"""
        return self.plugin_manager.get_completed_poem_ids(poem_ids, model_identifier)

# 全局数据管理器实例
data_manager = None


def get_data_manager(db_name: str = "default"):
    """获取数据管理器实例，支持在运行时切换数据库"""
    global data_manager
    if data_manager is None or data_manager.db_name != db_name:
        data_manager = DataManager(db_name=db_name)
    return data_manager