"""
插件化数据管理器
"""
from typing import List, Dict, Any, Optional
from src.data.plugin_interfaces.data_manager import DataManagerPlugin
from src.data.plugin_interfaces.data_model import DataModelPlugin
from src.component_system import get_component_system, ComponentType
from pathlib import Path


class PluginBasedDataManager:
    """插件化数据管理器"""
    
    def __init__(self, project_root: Path, db_name: str = "default"):
        self.project_root = project_root
        self.db_name = db_name
        self.component_system = get_component_system(project_root)
        
        # 获取数据管理插件
        self.data_manager_plugin: DataManagerPlugin = self.component_system.get_component(
            ComponentType.DATA_MANAGER, db_name=db_name
        )
        
        # 获取数据模型插件
        self.data_model_plugin: DataModelPlugin = self.component_system.get_component(
            ComponentType.DATA_MANAGER  # 使用相同类型获取数据模型插件
        )
    
    def initialize_database_from_json(self, clear_existing: bool = False) -> Dict[str, int]:
        """从JSON文件初始化数据库"""
        return self.data_manager_plugin.initialize_database_from_json(clear_existing)
    
    def get_poems_to_annotate(self, model_identifier: str, 
                               limit: Optional[int] = None, 
                               start_id: Optional[int] = None, 
                               end_id: Optional[int] = None,
                               force_rerun: bool = False) -> List:
        """获取指定模型待标注的诗词"""
        return self.data_manager_plugin.get_poems_to_annotate(
            model_identifier, limit, start_id, end_id, force_rerun
        )
    
    def get_poem_by_id(self, poem_id: int) -> Optional:
        """根据ID获取单首诗词信息"""
        return self.data_manager_plugin.get_poem_by_id(poem_id)
    
    def get_poems_by_ids(self, poem_ids: List[int]) -> List:
        """根据ID列表获取诗词信息"""
        return self.data_manager_plugin.get_poems_by_ids(poem_ids)
    
    def save_annotation(self, poem_id: int, model_identifier: str, status: str,
                        annotation_result: Optional[str] = None, 
                        error_message: Optional[str] = None) -> bool:
        """保存标注结果"""
        return self.data_manager_plugin.save_annotation(
            poem_id, model_identifier, status, annotation_result, error_message
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        return self.data_manager_plugin.get_statistics()
    
    def get_annotation_statistics(self) -> Dict[str, Any]:
        """获取标注统计信息"""
        return self.data_manager_plugin.get_annotation_statistics()
    
    def get_all_authors(self) -> List:
        """获取所有作者信息"""
        return self.data_manager_plugin.get_all_authors()
    
    def search_poems(self, author: Optional[str] = None, title: Optional[str] = None, 
                     page: int = 1, per_page: int = 10) -> Dict[str, Any]:
        """根据作者和标题搜索诗词，并支持分页"""
        return self.data_manager_plugin.search_poems(author, title, page, per_page)
    
    def get_completed_poem_ids(self, poem_ids: List[int], model_identifier: str) -> set[int]:
        """高效检查一组 poem_id 是否已被特定模型成功标注"""
        return self.data_manager_plugin.get_completed_poem_ids(poem_ids, model_identifier)
    
    def get_poem_model(self):
        """获取诗词数据模型类"""
        return self.data_model_plugin.get_poem_model()
    
    def get_author_model(self):
        """获取作者数据模型类"""
        return self.data_model_plugin.get_author_model()
    
    def get_annotation_model(self):
        """获取标注数据模型类"""
        return self.data_model_plugin.get_annotation_model()