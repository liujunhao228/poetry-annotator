"""
默认查询插件实现
"""
from typing import List, Dict, Any, Optional
import pandas as pd
from src.data.plugin_interfaces.query import QueryPlugin


class DefaultQueryPlugin(QueryPlugin):
    """默认查询插件实现"""
    
    def get_name(self) -> str:
        return "default_query"
    
    def get_description(self) -> str:
        return "默认查询插件实现"
    
    def execute_query(self, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        # 默认实现返回空DataFrame
        return pd.DataFrame()
    
    def get_required_params(self) -> List[str]:
        return []