"""
数据管理模块入口文件

注意：数据库初始化功能已移至 src/db_initializer 模块
"""
from .manager import DataManager, get_data_manager
from .adapter import get_database_adapter
from ..db_initializer.functions import initialize_all_databases_from_source_folders
from ..db_initializer.initializer import get_db_initializer
from .models import Poem, Author, Annotation
from .exceptions import DataError, DatabaseError
from .visualizer.queries import VisualizationQueries
from .plugin_based_manager import PluginBasedDataManager

__all__ = [
    "DataManager",
    "get_data_manager",
    "get_database_adapter",
    "get_db_initializer",
    "initialize_all_databases_from_source_folders",
    "Poem",
    "Author",
    "Annotation",
    "DataError",
    "DatabaseError",
    "VisualizationQueries",
    "PluginBasedDataManager"
]